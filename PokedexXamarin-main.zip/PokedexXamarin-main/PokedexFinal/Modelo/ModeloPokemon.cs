﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PokedexFinal.Modelo
{
    public class ModeloPokemon
    {
        public string ColorBack { get; set; }
        public string ColorTipo { get; set; }
        public string Imagen { get; set; }
        public string Nombre { get; set; }
        public string Numero { get; set; }
        public string Tipo { get; set; }
        public string Idpokemon { get; set; }
    }
}
