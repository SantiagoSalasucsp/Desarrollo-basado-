# PokedexXamarin
<h1>Integrantes:</h1>

- Nikolas Zuñiga Monroy
- Jean Marc Nadeau Huamani
- Alexis Espinoza Villanueva
- Alain Mullisaca Rivera
<h1>MenuPrincipal:</h1>

![Ejemplo1](https://github.com/NikolasZM/PokedexXamarin/assets/101744161/753df591-024c-41ef-acfc-ac6f00e59572)

<h1>Pokemon:</h1>

![Imagen2](https://github.com/NikolasZM/PokedexXamarin/assets/101744161/c267e0b8-427a-4623-8f66-57186d4eee41)

<h1>Formulario de registro:</h1>

![Ejemplo3](https://github.com/NikolasZM/PokedexXamarin/assets/101744161/0676d9ab-7bfa-4e04-97ec-99f4c27669eb)
